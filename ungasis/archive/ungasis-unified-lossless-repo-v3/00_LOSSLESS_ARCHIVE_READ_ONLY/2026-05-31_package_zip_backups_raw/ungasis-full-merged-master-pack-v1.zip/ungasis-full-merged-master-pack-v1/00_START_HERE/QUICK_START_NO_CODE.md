# Quick Start for Non-Technical Users

## Step 1: Unzip the file
Right-click the ZIP file and choose **Extract** or **Unzip**.

## Step 2: Open the main folder
Open:

```text
ungasis-full-merged-master-pack-v1
```

## Step 3: Read the status
Open:

```text
02_MERGED_FINAL_RECOMMENDED/MASTER_STATUS.md
```

## Step 4: Keep the backup safe
Do not edit this folder:

```text
01_ORIGINAL_FILES_BACKUP
```

It is your safety copy.

## Step 5: Use the final folder
The useful working folder is:

```text
02_MERGED_FINAL_RECOMMENDED
```

## Step 6: Ask for help with production
When you want real production use, send this file to a developer:

```text
05_DEVELOPER_HANDOFF/DEVELOPER_HANDOFF_PROMPT.md
```

## Tiny check
If you only remember one thing:

Use `02_MERGED_FINAL_RECOMMENDED` and keep `01_ORIGINAL_FILES_BACKUP` untouched.
