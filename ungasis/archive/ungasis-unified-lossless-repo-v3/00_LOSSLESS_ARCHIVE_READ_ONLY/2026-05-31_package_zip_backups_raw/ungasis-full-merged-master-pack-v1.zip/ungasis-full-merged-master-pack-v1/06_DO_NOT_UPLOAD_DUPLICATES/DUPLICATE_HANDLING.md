# Duplicate Handling

## What I did
I did not overwrite duplicate names.

Instead, I placed each kit in its own folder.

## Why
Some files have the same name but different purpose.

Example:

```text
README.md
```

A README in the multi-agent kit is not the same as a README in the token-efficiency kit.

## Rule
Keep duplicate names inside their own component folders.
Do not flatten all files into one folder.
