# What Not To Upload

Do not upload these into ChatGPT Project knowledge unless you are restoring or auditing:

```text
01_ORIGINAL_FILES_BACKUP/
original_zip_files/
extracted_originals/
*.zip
.env
.env.local
any file with real passwords or API keys
```

## Why
Backups and duplicates confuse the project.

## Simple analogy
Do not put old drafts and final papers into the same school submission.
