# Production Readiness Task List

## Must do before production

- [ ] Create Git repository
- [ ] Add real license
- [ ] Add or confirm CODEOWNERS
- [ ] Add secret scanning
- [ ] Add dependency scanning
- [ ] Add schema validation
- [ ] Add CI
- [ ] Run CI in GitHub
- [ ] Add runtime implementation or mark runtime as blueprint
- [ ] Add logs
- [ ] Test rollback
- [ ] Test human approval gates
- [ ] Test red-team prompts
- [ ] Review permissions
- [ ] Review deployment path
- [ ] Write final readiness report

## Nice to have later

- [ ] SBOM
- [ ] signed releases
- [ ] artifact attestations
- [ ] dashboard for logs
- [ ] automated eval report
