# Developer Handoff Prompt

Copy this and send it to a developer or coding assistant.

```text
Act as a senior end-to-end app developer, AI-agent architect, security reviewer, and release engineer.

Goal:
Turn this UNGASIS merged master pack into a production-ready repository.

Important:
Preserve original files. Do not delete backups. Do not expose secrets. Do not call it production-ready until tests pass.

Inputs:
- 00_UNGASIS_CORE
- 01_MULTI_AGENT_ORCHESTRATION_KIT
- 02_TOKEN_EFFICIENCY_AGENT_OS
- 03_PRODUCTION_READINESS_LAYER
- 04_MASTER_GOVERNANCE

Tasks:
1. Create one clean Git repository from 02_MERGED_FINAL_RECOMMENDED.
2. Keep backup files outside the active repo or in an archived folder.
3. Mark each file as Active, Template, Example, Backup, or Future.
4. Remove active placeholders.
5. Choose and add a real LICENSE.
6. Review SECURITY.md, CODEOWNERS, CONTRIBUTING.md, RUNBOOK, and INCIDENT_RESPONSE.
7. Add schema validation for YAML/JSON configs.
8. Add CI that runs local checks, secret scans, config checks, prompt tests, and red-team tests.
9. Pin GitHub Actions or document why not yet pinned.
10. Add agent permission profiles: read-only, draft, patch, test, release.
11. Add human approval gates for risky actions.
12. Add runtime logging with run ID, agent, tool, approval, error, and rollback link.
13. Implement or clearly label the orchestration runtime as blueprint only.
14. Run smoke tests and regression tests.
15. Produce a final readiness report with PASS/HOLD decision.

Acceptance criteria:
- All checks pass in CI.
- No secrets are committed.
- No active placeholders remain.
- Rollback is tested.
- Human approval gates are tested.
- Runtime claims are true.
- Production status is honest.
```
