# Current Best-Practice Notes

These notes explain why the production-readiness pack includes security, CI, permissions, approval, and logs.

## GitHub Actions
Use least-privilege workflow permissions. Store secrets safely. Review third-party actions. Pin actions when possible.

## AI app security
Test against prompt injection, data leaks, unsafe tool use, excessive agency, and unbounded cost.

## AI risk management
Use governance, mapping, measurement, and management as a cycle, not a one-time checklist.

## Software supply chain
Track outside tools and packages. Use trusted sources. Consider provenance, SBOM, and signed releases later.

## Observability
Add logs, traces, and metrics so a developer can see what happened when something breaks.

## Simple analogy
Good production work is not only building the app.
It is also adding locks, smoke alarms, receipts, and emergency exits.
