# Technical Jargon: Feynman + Layman Analogies

Use this when a word feels confusing.

| Word | Simple meaning | Feynman explanation | Layman analogy |
|---|---|---|---|
| Production-ready | Safe enough for real users | The system has been tested, secured, documented, and can be fixed if it breaks. | A restaurant ready to serve paying customers. |
| Repository | Project folder | One place where files, history, and rules live. | A labeled binder for a project. |
| ZIP | Compressed folder | Many files packed into one file. | A suitcase. |
| Merge | Combine cleanly | Put useful parts together without losing the original. | Combining notes into one organized binder. |
| Backup | Safety copy | A copy you keep in case the new version breaks. | Spare house key. |
| Active file | Used now | A real file the system depends on. | Real medicine bottle. |
| Template | Fill-in sample | A file you copy and complete later. | Blank school form. |
| Placeholder | Empty value | A spot waiting for real information. | “Dear [NAME]” in a letter. |
| Config | Settings file | A file that tells the system how to behave. | TV remote settings. |
| Schema | Shape checker | A rule file that checks if a config has the right parts. | School form checker. |
| CI | Automatic checker | A robot that runs tests when files change. | Guard checking tickets at the door. |
| GitHub Actions | GitHub robot worker | GitHub runs jobs like tests and checks for you. | A factory inspection machine. |
| Secret | Private key | Passwords, API keys, and tokens that must be hidden. | House key. |
| API key | App password | A code that lets software use a service. | Membership card for a private club. |
| Permission | Allowed action | Rules for what a person, tool, or AI may do. | Visitor badge. |
| Least privilege | Smallest needed access | Give only the access needed for the task. | Give a guest the bathroom key, not the bank vault key. |
| Agent | AI worker | An AI part assigned to a job. | Team member. |
| Tool | Action helper | Something the AI can use, like file search or code runner. | Hammer or calculator. |
| Runtime | Running system | The part that actually executes the work. | A car engine running. |
| Orchestration | Coordinated work | Many steps, tools, and agents working in order. | A conductor leading an orchestra. |
| MCP | Connector standard | A way for AI tools to connect to outside systems. | Universal adapter plug. |
| Token | AI text unit | A small chunk of text the AI reads or writes. | Word piece. |
| Prompt | Instruction to AI | The task you give the AI. | Work order. |
| Eval | AI test | A test that checks if AI behaves correctly. | Exam. |
| Red-team test | Attack test | A test that tries to break rules safely. | Fire drill. |
| Smoke test | Quick basic test | A fast check that the main thing works. | Turning lights on after wiring. |
| Regression test | Recheck old behavior | Makes sure old working parts still work. | Checking repaired brakes again. |
| Release | New version goes out | A version is published for use. | Opening day. |
| Rollback | Undo release | Return to the last safe version. | Save point in a game. |
| Changelog | Change list | Notes about what changed. | Receipt for project edits. |
| CODEOWNERS | Review owners | A file saying who must review important changes. | Manager signature rule. |
| Security policy | Safety rules | Tells people how to report security problems. | Emergency contact sheet. |
| Incident response | Emergency plan | What to do when something goes wrong. | Fire escape plan. |
| Observability | See what happened | Logs and traces that explain system behavior. | CCTV plus receipt. |
| Log | Event note | A written record of what happened. | Diary entry. |
| Trace | Step path | A record of the steps in one run. | Breadcrumb trail. |
| Metric | Number to watch | A measurement that shows health or performance. | Speedometer. |
| Supply chain | Outside parts | Code, tools, actions, and packages your project depends on. | Food ingredients from suppliers. |
| Dependency | Needed outside part | A library or tool your project uses. | Battery for a remote. |
| Environment | Place where app runs | Local, test, staging, or production setup. | Kitchen, test kitchen, restaurant kitchen. |
| Staging | Practice production | A test place similar to real production. | Dress rehearsal. |
| Deployment | Put online | Move the app to where users can access it. | Opening the shop. |
| RAG | Search plus AI answer | AI looks up your documents before answering. | Open-book exam. |
| Vector database | Meaning search storage | Stores text so AI can find similar ideas. | Library organized by meaning, not alphabet. |
| Connector | System bridge | Lets one app talk to another. | Phone charger adapter. |
| Rate limit | Usage speed limit | Caps how often something can be used. | Road speed limit. |
| Lint | Style/error checker | Finds simple mistakes before running. | Spell-check for code/config. |
| YAML | Human-friendly data file | A text format for settings. | Organized checklist. |
| JSON | Machine-friendly data file | A text format apps read easily. | Labeled boxes. |
| Validation | Check against rules | Proves the file follows required rules. | Teacher checking homework format. |
