# No-Code Upload Decision Tree

## Should I upload this file to ChatGPT Project?

Start here:

```text
Is it a backup ZIP?
  Yes -> Do not upload.
  No -> Continue.

Is it an original duplicate copy?
  Yes -> Do not upload unless restoring.
  No -> Continue.

Is it one of the core UNGASIS knowledge files?
  Yes -> Upload if you are updating project knowledge.
  No -> Continue.

Is it a production-readiness guide or checklist?
  Yes -> Upload if you want ChatGPT to use it as project knowledge.
  No -> Continue.

Does it contain secrets or private data?
  Yes -> Do not upload.
  No -> Upload only if useful.
```

## Safest upload set

Upload these first:

```text
02_MERGED_FINAL_RECOMMENDED/00_UNGASIS_CORE/
02_MERGED_FINAL_RECOMMENDED/03_PRODUCTION_READINESS_LAYER/07_PRODUCTION_READINESS_SECURITY_QA.md
02_MERGED_FINAL_RECOMMENDED/03_PRODUCTION_READINESS_LAYER/08_AGENT_EVALS_AND_RUNTIME_GOVERNANCE.md
02_MERGED_FINAL_RECOMMENDED/03_PRODUCTION_READINESS_LAYER/09_CONNECTOR_PERMISSION_REGISTRY.md
02_MERGED_FINAL_RECOMMENDED/03_PRODUCTION_READINESS_LAYER/10_OBSERVABILITY_AND_INCIDENT_RESPONSE.md
02_MERGED_FINAL_RECOMMENDED/03_PRODUCTION_READINESS_LAYER/11_SCHEMA_CONTRACT_SYSTEM.md
02_MERGED_FINAL_RECOMMENDED/03_PRODUCTION_READINESS_LAYER/12_RELEASE_AND_ROLLBACK.md
02_MERGED_FINAL_RECOMMENDED/03_PRODUCTION_READINESS_LAYER/13_SUPPLY_CHAIN_SECURITY.md
```

## Do not upload

```text
01_ORIGINAL_FILES_BACKUP
original_zip_files
extracted_originals
validation reports with local paths
any .env file with real secrets
```
