# Release and Rollback Minimum

## Release means
You publish a new version.

## Rollback means
You go back to the last safe version.

## Before release

- [ ] version number set
- [ ] change log updated
- [ ] tests passed
- [ ] backup made
- [ ] rollback steps written
- [ ] owner approved

## Feynman explanation
A rollback is an undo plan.

## Layman analogy
Like saving a game before fighting a boss.
