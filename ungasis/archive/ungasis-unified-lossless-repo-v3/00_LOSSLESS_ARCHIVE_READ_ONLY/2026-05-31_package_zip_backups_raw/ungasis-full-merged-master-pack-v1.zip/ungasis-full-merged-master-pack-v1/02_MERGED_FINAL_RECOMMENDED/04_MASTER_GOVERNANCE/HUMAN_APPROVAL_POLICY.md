# Human Approval Policy

AI must ask a human before risky actions.

## Always require approval before

- sending messages
- deleting files
- changing permissions
- posting public content
- updating records
- submitting forms
- moving money
- using secrets
- touching legal, health, finance, HR, or security data

## Feynman explanation
A human approval gate stops the AI before it does something that can cause harm.

## Layman analogy
Like a cashier asking a manager before giving a large refund.
