# Master Manifest

## Purpose
This file explains the main folders in the merged package.

| Folder | Use |
|---|---|
| `00_UNGASIS_CORE` | ChatGPT Project knowledge and UNGASIS operating files. |
| `01_MULTI_AGENT_ORCHESTRATION_KIT` | Agent workflow and orchestration kit. |
| `02_TOKEN_EFFICIENCY_AGENT_OS` | Token-saving agent/coding workflow kit. |
| `03_PRODUCTION_READINESS_LAYER` | Safety, QA, security, schemas, CI starter, and release files. |
| `04_MASTER_GOVERNANCE` | Final readiness gates and production blockers. |
| `.github/workflows` | Starter CI workflow for developer review. |
| `scripts` | Local check script. |

## Current status
Use for learning, internal testing, and developer handoff.
Do not use with real users until production gates pass.
