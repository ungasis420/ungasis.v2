# Readiness Gate

## Current gate
**Private testing only.**

## Production gate checklist
Do not call this production-ready until every item is checked:

- [ ] All active placeholders removed
- [ ] License chosen
- [ ] Security file reviewed
- [ ] CI runs in GitHub
- [ ] Secret scan passes
- [ ] Config schema checks pass
- [ ] Prompt tests pass
- [ ] Red-team tests pass
- [ ] Runtime test passes
- [ ] Logs work
- [ ] Human approval gates work
- [ ] Rollback tested
- [ ] Developer review done
- [ ] Security review done

## Feynman explanation
A readiness gate is a list of checks that must pass before launch.

## Layman analogy
Like an airport gate: you do not board until your ticket and ID are checked.
