# Production Blockers

These must be fixed before real production use.

## Blocker 1: Runtime is not proven
The orchestration kit describes flows, but the full live system still needs real runtime testing.

## Blocker 2: CI is not proven
The checks need to run in GitHub, not only on a local machine.

## Blocker 3: Secrets are not fully verified
A real secret scanner should check the repository.

## Blocker 4: Permissions need review
AI agents need clear read, write, run, delete, and send limits.

## Blocker 5: Rollback is not tested
A bad release must be reversible.

## Blocker 6: Human approval must be tested
Risky AI actions must stop and ask first.

## Simple analogy
A restaurant menu is not the same as a working kitchen.

This pack gives the menu, recipes, and safety rules. A developer still needs to test the kitchen.
