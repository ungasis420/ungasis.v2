# Secret Safety Rules

A secret is private information.

Examples:

- API key
- password
- token
- database URL
- private certificate

## Rules

1. Do not paste secrets into ChatGPT.
2. Do not save secrets inside ZIP files.
3. Do not put secrets in frontend code.
4. Use `.env.example` only as a sample.
5. Put real secrets in a secure secret manager or environment setting.

## Feynman explanation
Secrets are digital keys. If other people see them, they can open your doors.

## Layman analogy
Do not tape your house key beside your front door.
