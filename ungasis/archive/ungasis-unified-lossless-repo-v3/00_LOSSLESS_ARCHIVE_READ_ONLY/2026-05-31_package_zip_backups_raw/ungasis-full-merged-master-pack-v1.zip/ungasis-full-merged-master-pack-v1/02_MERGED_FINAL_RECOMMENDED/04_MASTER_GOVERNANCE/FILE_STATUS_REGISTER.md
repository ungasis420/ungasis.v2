# File Status Register

Use this file to mark what each file is.

| Status | Meaning | Rule |
|---|---|---|
| Active | Used now | Must be complete. |
| Template | Copy and fill later | Placeholders are okay. |
| Example | Shows how something works | Do not treat as real config. |
| Backup | Saved copy | Do not edit unless restoring. |
| Future | Planned idea | Do not claim it works yet. |

## Starter status

| Folder | Status | Notes |
|---|---|---|
| `00_UNGASIS_CORE` | Active knowledge | Upload/update carefully. |
| `01_MULTI_AGENT_ORCHESTRATION_KIT` | Private beta / needs runtime check | Good blueprint, not production runtime yet. |
| `02_TOKEN_EFFICIENCY_AGENT_OS` | Private beta / local use | Good workflow kit, needs permission hardening. |
| `03_PRODUCTION_READINESS_LAYER` | Active support layer | Adds checks, docs, schemas, safety files. |
| `04_MASTER_GOVERNANCE` | Active support layer | Use for readiness decisions. |
