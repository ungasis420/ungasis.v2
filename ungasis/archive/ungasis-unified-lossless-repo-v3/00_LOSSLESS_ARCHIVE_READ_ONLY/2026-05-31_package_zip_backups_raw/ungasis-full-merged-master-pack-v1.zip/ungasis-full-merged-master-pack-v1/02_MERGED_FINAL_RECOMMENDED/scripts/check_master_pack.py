#!/usr/bin/env python3
from pathlib import Path
import json, re, sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    '00_UNGASIS_CORE/VERSION_MANIFEST.md',
    '01_MULTI_AGENT_ORCHESTRATION_KIT/README.md',
    '02_TOKEN_EFFICIENCY_AGENT_OS/README.md',
    '03_PRODUCTION_READINESS_LAYER/07_PRODUCTION_READINESS_SECURITY_QA.md',
    '03_PRODUCTION_READINESS_LAYER/08_AGENT_EVALS_AND_RUNTIME_GOVERNANCE.md',
    '03_PRODUCTION_READINESS_LAYER/09_CONNECTOR_PERMISSION_REGISTRY.md',
    '03_PRODUCTION_READINESS_LAYER/10_OBSERVABILITY_AND_INCIDENT_RESPONSE.md',
    '04_MASTER_GOVERNANCE/READINESS_GATE.md',
]
fail = []
for item in required:
    if not (ROOT / item).exists():
        fail.append(f'Missing required file: {item}')

# JSON schema syntax check
for p in (ROOT/'03_PRODUCTION_READINESS_LAYER').rglob('*.json'):
    try:
        json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        fail.append(f'Invalid JSON: {p.relative_to(ROOT)}: {e}')

# Secret pattern light check - not a full scanner
secret_patterns = [
    r'AKIA[0-9A-Z]{16}',
    r'sk-[A-Za-z0-9]{20,}',
    r'ghp_[A-Za-z0-9]{20,}',
    r'AIza[0-9A-Za-z\-_]{20,}',
]
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.md','.txt','.yml','.yaml','.json','.py','.sh','.env'}:
        try:
            txt = p.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            continue
        for pat in secret_patterns:
            if re.search(pat, txt):
                fail.append(f'Possible secret pattern in: {p.relative_to(ROOT)}')

print('UNGASIS master pack check')
print('-------------------------')
if fail:
    print('Result: NEEDS REVIEW')
    for f in fail:
        print('- ' + f)
    sys.exit(1)
else:
    print('Result: PASS')
    print('Basic files, JSON schemas, and light secret pattern check look okay.')
