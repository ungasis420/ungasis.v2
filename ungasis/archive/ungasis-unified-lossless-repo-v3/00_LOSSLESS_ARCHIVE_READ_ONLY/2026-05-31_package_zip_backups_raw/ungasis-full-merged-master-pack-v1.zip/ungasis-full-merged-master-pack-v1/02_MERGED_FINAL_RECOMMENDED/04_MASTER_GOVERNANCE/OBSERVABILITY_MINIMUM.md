# Observability Minimum

Observability means you can see what happened.

## Log these things

- run ID
- date and time
- user request summary
- agent name
- tool used
- file changed
- approval status
- error message
- rollback step

## Feynman explanation
If something breaks, logs help you answer: what happened, when, and why?

## Layman analogy
Like a receipt plus CCTV for your system.
