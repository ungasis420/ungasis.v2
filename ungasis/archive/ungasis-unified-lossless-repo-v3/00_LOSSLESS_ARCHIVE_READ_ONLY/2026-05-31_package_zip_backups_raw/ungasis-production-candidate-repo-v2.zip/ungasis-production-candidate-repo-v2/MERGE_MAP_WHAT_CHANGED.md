# Merge Map: What Changed

## Goal

Turn three ZIP files into one cleaner repository.

## Source ZIPs

| ZIP | Role |
|---|---|
| `multi-agent-orchestration-kit-v4.zip` | Agent workflow and orchestration blueprint. |
| `token-efficiency-agent-os-v4.zip` | Token-saving AI coding workflow rules. |
| `ungasis-production-readiness-pack-v1.zip` | Security, QA, schemas, tests, and learner guides. |

## Backup rule

No original ZIP was deleted.

Original ZIPs are stored in:

```text
01_ORIGINAL_ZIP_BACKUPS/
```

Extracted originals are stored in:

```text
02_EXTRACTED_ORIGINALS_READ_ONLY/
```

## Main merge decisions

| Decision | What happened | Why |
|---|---|---|
| Root README replaced | New merged `README.md` created | Avoid duplicate/confusing README files. |
| Original README files preserved | Saved inside extracted backups or docs/original folders | No information loss. |
| Token AI tool settings hardened | `.claude/settings.json` changed to read-only default | Safer beginner default. |
| Aider auto-commit disabled | `.aider.conf.yml` sets `auto-commits: false` | Prevents silent commits. |
| Production files added | Security, runbook, rollback, schemas, tests | Needed before production use. |
| CI added | `.github/workflows/ci.yml` | Automatic checking. |
| File status register added | `FILE_STATUS_REGISTER.csv` | Every file is marked. |

## Duplicate rule

When duplicate files had the same purpose, the merged repo keeps one active version and preserves originals in backup folders.
