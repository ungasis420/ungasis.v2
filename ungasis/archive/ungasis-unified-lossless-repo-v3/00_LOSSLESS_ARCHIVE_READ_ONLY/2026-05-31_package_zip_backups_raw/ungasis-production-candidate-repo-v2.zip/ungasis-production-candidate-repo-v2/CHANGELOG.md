# Changelog

## 2026-05-30 - v1 merged master repository

### Added

- merged repository structure
- original ZIP backups
- extracted original backups
- production readiness files
- schema files
- local validation script
- CI workflow
- permission matrix
- human approval gates
- observability sample
- release and rollback docs
- beginner guides and glossary

### Changed

- root README now explains the merged repo
- `.claude/settings.json` now defaults to read-only
- `.aider.conf.yml` now disables auto-commits

### Removed

- No source material was deleted. Originals are preserved in backup folders.
